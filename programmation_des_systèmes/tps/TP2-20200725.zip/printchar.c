#include  <stdio.h>




void main(){
char c1 = 0x73;
printf(" c1 = %2x\n",c1);

c1 = 0x83;
printf(" c1 = %2x\n",c1);

c1 = 0x73;
printf(" c1 = %4x\n",c1);

c1 = 0x83;
printf(" c1 = %4x\n",c1);

unsigned char c2 = 0x73;
printf(" c2 = %2x\n",c2);

c2 = 0x83;
printf(" c2 = %2x\n",c2);

c2 = 0x73;
printf(" c2 = %4x\n",c2);

c2 = 0x83;
printf(" c2 = %4x\n",c2);

} 
