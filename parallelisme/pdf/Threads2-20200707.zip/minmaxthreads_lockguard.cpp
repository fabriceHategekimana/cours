#include <algorithm>
#include <iostream>
#include <vector>
#include <mutex>
#include <thread>
 
const size_t size = 1e8;
 
struct iminmax_t{
  size_t min, max;
};
 
/******************************************************************************
* Fonctions et donnees pour  la recherche avec des threads
******************************************************************************/
 
volatile iminmax_t indshared;
volatile int minshared, maxshared;
std::mutex mut;
 
// cherche le min et le max dans l'interval [low, up[ de vec
// enregistre la valeur de l'indice du minimum et du maximum dans indshared
void minmaxthread(int* vec, size_t low, size_t up){
  iminmax_t indloc = {low, low};
  int minloc = vec[indloc.min]; int maxloc = vec[indloc.max];
  for(size_t i=low; i<up; i++){
    if(vec[i] < minloc){
      indloc.min = i;
      minloc = vec[i];
    }
    if(vec[i] > maxloc){
      indloc.max = i;
      maxloc = vec[i];
    }
  }
 
  // on a remplace ici le mut.lock() et mut.unlock() par la construction d'un lock_guard
  std::lock_guard<std::mutex> lock(mut);
 
  if(maxloc > maxshared){
    maxshared = maxloc;
    indshared.max = indloc.max;
  }
  if(minloc < minshared){
    minshared = minloc;
    indshared.min = indloc.min;
  }
}
 
// construit n threads qui cherchent le minimum et le maximum de vec
// retourne l'indice du minimum et du maximum
iminmax_t findMinMaxThread(std::vector<int> &vec, int n){
  indshared.min = 0; indshared.max = 0;
  minshared = vec[indshared.min]; maxshared = vec[indshared.max];
  std::vector<std::thread> threads;
  for(int i = 1; i<n; i++){
    threads.push_back(std::thread(minmaxthread, vec.data(), i*vec.size()/n, i*vec.size()/n+vec.size()/n));
  }
  minmaxthread(vec.data(), 0, vec.size()/n);
  for(auto& t : threads) t.join();
  iminmax_t res = {indshared.min, indshared.max};
  return res;
}
 
int main(int argc, char** argv){
 
  // nombre de threads a creer
  int n = atoi(argv[1]);
 
  // generation du vecteur aleatoire
  std::random_device rnd_device;
  std::mt19937 mersenne_engine(rnd_device());
  std::uniform_int_distribution<int> dist(
    std::numeric_limits<int>::min(),
    std::numeric_limits<int>::max());
  auto gen = std::bind(dist, mersenne_engine);
  std::vector<int> vec(size);
  std::generate(vec.begin(), vec.end(), gen);
 
  // recherche du minimum et du maximum avec des threads
  auto i = findMinMaxThread(vec, n);
  std::cout << "min " << vec[i.min] << " found in position " << i.min << std::endl;
  std::cout << "max " << vec[i.max] << " found in position " << i.max << std::endl;
 
}