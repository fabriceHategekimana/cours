#include <algorithm>
#include <iostream>
#include <vector>
#include <chrono>
#include <mutex>
#include <thread>
#include <future>
 
const size_t size = 1e8;
 
struct iminmax_t{
  size_t min, max;
};
 
/******************************************************************************
* Fonctions et donnees pour  la recherche avec des threads
******************************************************************************/
 
iminmax_t indshared;
int minshared, maxshared;
std::mutex mut;
 
// cherche le min et le max dans l'interval [low, up[ de vec
// enregistre la valeur de l'indice du minimum et du maximum dans indshared
void minmaxthread(int* vec, size_t low, size_t up){
  iminmax_t indloc = {low, low};
  auto minloc = vec[indloc.min]; auto maxloc = vec[indloc.max];
  for(size_t i=low; i<up; i++){
    if(vec[i] < minloc){
      indloc.min = i;
      minloc = vec[i];
    }
    if(vec[i] > maxloc){
      indloc.max = i;
      maxloc = vec[i];
    }
  }
  mut.lock();
  if(maxloc > maxshared){
    maxshared = maxloc;
    indshared.max = indloc.max;
  }
  if(minloc < minshared){
    minshared = minloc;
    indshared.min = indloc.min;
  }
  mut.unlock();
}
 
// construit n threads qui cherchent le minimum et le maximum de vec
// retourne l'indice du minimum et du maximum
iminmax_t findMinMaxThread(std::vector<int> &vec, int n){
  indshared.min = 0; indshared.max = 0;
  minshared = vec[indshared.min]; maxshared = vec[indshared.max];
  std::vector<std::thread> threads;
  for(int i = 1; i<n; i++){
    threads.push_back(std::thread(minmaxthread, vec.data(), i*vec.size()/n, i*vec.size()/n+vec.size()/n));
  }
  minmaxthread(vec.data(), 0, vec.size()/n);
  for(auto& t : threads) t.join();
  return indshared;
}
 
/******************************************************************************
* Fonctions pour la recherche sequentielle et avec des futures
******************************************************************************/
 
// cherche le min et le max dans l'interval [low, up[ de vec
// retourne l'indice du minimum et du maximum
iminmax_t minmax(int* vec, size_t low, size_t up){
  iminmax_t ind = {low, low};
  int min = vec[ind.min]; int max = vec[ind.max];
  for(size_t i=low; i<up; i++){
    if(vec[i] < min){
      ind.min = i;
      min = vec[i];
    }
    if(vec[i] > max){
      ind.max = i;
      max = vec[i];
    }
  }
  return ind;
}
 
// construit n futures qui cherchent le minimum et le maximum de vec
// retourne l'indice du minimum et du maximum
iminmax_t findMinMaxFuture(std::vector<int> &vec, int n){
  std::vector<std::future<iminmax_t>> futures;
  for(size_t i=0; i<n; i++){
    futures.push_back(std::async(std::launch::async, minmax, vec.data(), i*vec.size()/n, i*vec.size()/n + vec.size()/n));
  }
  auto ind = futures[0].get();
  for(size_t i=1; i<n; i++){
    auto res = futures[i].get();
    if(vec[res.min] < vec[ind.min]) ind.min = res.min;
    if(vec[res.max] > vec[ind.max]) ind.max = res.max;
  }
  return ind;
}
 
// recherche sequentielle du minimum et du maximum de vec
// retourne l'indice du minimum et du maximum
iminmax_t findMinMaxSeq(std::vector<int> &vec){
  return minmax(vec.data(), 0, vec.size());
}
 
 
int main(int argc, char** argv){
 
  // nombre de threads et futures a creer
  int n = atoi(argv[1]);
 
  // generation du vecteur aleatoire
  std::random_device rnd_device;
  std::mt19937 mersenne_engine(rnd_device());
  std::uniform_int_distribution<int> dist(
    std::numeric_limits<int>::min(),
    std::numeric_limits<int>::max());
  auto gen = std::bind(dist, mersenne_engine);
  std::vector<int> vec(size);
  std::generate(vec.begin(), vec.end(), gen);
 
  // recherche du minimum et du maximum avec les trois methodes
  // sequentiel, threads et futures
  std::cout << "sequential search ..." << std::endl;
  auto start = std::chrono::steady_clock::now();
  auto i = findMinMaxSeq(vec);
  auto end = std::chrono::steady_clock::now();
  auto diff = end - start;
  std::cout << "min " << vec[i.min] << " found at position " << i.min << std::endl;
  std::cout << "max " << vec[i.max] << " found at position " << i.max << std::endl;
  std::cout << "search time : " << std::chrono::duration <double, std::milli> (diff).count() << " [ms]" << std::endl << std::endl;
 
  std::cout << "parallel search with " << n << " threads ..." << std::endl;
  start = std::chrono::steady_clock::now();
  i = findMinMaxThread(vec, n);
  end = std::chrono::steady_clock::now();
  diff = end - start;
  std::cout << "min " << vec[i.min] << " found at position " << i.min << std::endl;
  std::cout << "max " << vec[i.max] << " found at position " << i.max << std::endl;
  std::cout << "search time : " << std::chrono::duration <double, std::milli> (diff).count() << " [ms]" << std::endl << std::endl;
 
  std::cout << "parallel search with " << n << " futures ..." << std::endl;
  start = std::chrono::steady_clock::now();
  i = findMinMaxFuture(vec, n);
  end = std::chrono::steady_clock::now();
  diff = end - start;
  std::cout << "min " << vec[i.min] << " found at position " << i.min << std::endl;
  std::cout << "max " << vec[i.max] << " found at position " << i.max << std::endl;
  std::cout << "search time : " << std::chrono::duration <double, std::milli> (diff).count() << " [ms]" << std::endl << std::endl;
 
}