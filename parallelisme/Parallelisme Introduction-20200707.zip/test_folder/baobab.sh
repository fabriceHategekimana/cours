#!/bin/sh 
#SBATCH --cpus-per-task=1
#SBATCH --job-name=test
#SBATCH --ntasks=12
#SBATCH --time=0-00:01:00
#SBATCH --mail-user=Christos.Kotsalos@unige.ch
#SBATCH --mail-type=ALL
#SBATCH --partition=debug-EL7
#SBATCH --clusters=baobab
#SBATCH --output=slurm-%J.out

module load foss

srun test1
#srun test2
