#include <mpi.h>
#include <iostream>
#include <vector>
 
int main(int argc, char **argv) {
  int myRank, nProc;
 
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
  MPI_Comm_size(MPI_COMM_WORLD, &nProc); 
 
  // allocation, initialisation et somme locale
  std::vector<int> vLocal(10, myRank);
  int sumLocal = 0;
  for(auto i : vLocal) sumLocal += i;

  std::cout << "I'm process " << myRank << " and my local sum is " << sumLocal << std::endl;

  // reunion des donnees
  if(myRank != 0){
    MPI_Send(&sumLocal, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
  }else{
    int sumGlobal = sumLocal;
    int rec;
    MPI_Status status;
    for(int n=1; n<nProc;n++){
      MPI_Recv(&rec, 1, MPI_INT, n, 0, MPI_COMM_WORLD, &status);
      sumGlobal += rec;      
    }
    std::cout << "The gloabl sum is " << sumGlobal << std::endl;
  }  

  MPI_Finalize();
}
