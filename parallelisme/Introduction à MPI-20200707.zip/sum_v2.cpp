#include <mpi.h>
#include <iostream>
#include <vector>
 
int main(int argc, char **argv) {
  int myRank, nProc;
 
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
  MPI_Comm_size(MPI_COMM_WORLD, &nProc); 
 
  // allocation, initialisation et distribution des donnees
  std::vector<int> vLocal(10);
  if(myRank == 0){
    std::vector<int> vGlobal(10*nProc);
    int i = 0;
    for(auto& v : vGlobal) v = i++;
    vLocal.assign(vGlobal.begin(), vGlobal.begin()+10);
    for(int n=1; n<nProc; n++){
      MPI_Send(vGlobal.data()+10*n, 10, MPI_INT, n, 0, MPI_COMM_WORLD);
    }
  }else{
    MPI_Status status;
    MPI_Recv(vLocal.data(), 10, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
  }

  // somme locale
  int sumLocal = 0;
  for(auto i : vLocal) sumLocal += i;

  std::cout << "I'm process " << myRank << " and my local sum is " << sumLocal << std::endl;

  // reunion des donnees
  if(myRank != 0){
    MPI_Send(&sumLocal, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
  }else{
    int sumGlobal = sumLocal;
    int rec;
    MPI_Status status;
    for(int n=1; n<nProc;n++){
      MPI_Recv(&rec, 1, MPI_INT, n, 0, MPI_COMM_WORLD, &status);
      sumGlobal += rec;      
    }
    std::cout << "The global sum is " << sumGlobal << std::endl;
  }  

  MPI_Finalize();
}
