#include <mpi.h>
#include <iostream>
#include <vector>
#include <cstdlib> 
#include <ctime>

int main(int argc, char **argv) {
  int myRank, nProc;
  MPI_Status status;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &myRank);
  MPI_Comm_size(MPI_COMM_WORLD, &nProc);
    
  if(myRank != 0){
    srand(time(NULL)+myRank);
    int size = rand() % 10 + 1;
    std::vector<int> buf(size);
    for(auto& v : buf) v = myRank;

    MPI_Send(&size, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    MPI_Send(buf.data(), buf.size(), MPI_INT, 0, 1, MPI_COMM_WORLD);
  }
  else{
    std::vector<int> sizes(nProc);
    int size;
    MPI_Status status;
    for(int i=1; i<nProc; i++){
      MPI_Recv(&size, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
      sizes[status.MPI_SOURCE] = size;
    }
    std::vector<int> buf;
    for(int n=1; n<nProc; n++){
      buf.resize(sizes[n]);
      MPI_Recv(buf.data(), buf.size(), MPI_INT, n, 1, MPI_COMM_WORLD, &status);
      std::cout << "received data from p" << n << ", data received : ";
      for(auto v : buf) std::cout << v << ", ";             
      std::cout << std::endl;
    }
  }

  MPI_Finalize();
}

