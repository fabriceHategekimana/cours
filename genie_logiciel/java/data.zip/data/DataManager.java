package com.student.resources;

import java.util.HashMap;

public class DataManager {
	
	
	//Key = , Value = Student
	private HashMap<String, Student> listStudents = new HashMap<String, Student>();
	
	public DataManager() {
		super();
		initialiser();
	}

	public HashMap<String, Student> getStudents(){
		return listStudents;		 
	}
		
	public  void initialiser(){
		 listStudents.put("India", new Student("Cole","India","2014",new Study("IG"),1993));
		 listStudents.put("Joshua",new Student("Valentine","Joshua","2014",new Study("IG"),1991));
		 listStudents.put("Neville",new Student("Chelsea","Neville","2014",new Study("IG"),1991));
		 listStudents.put("Deborah", new Student("Cherokee","Deborah","2014",new Study("IG"),1992));
		 listStudents.put("Sean",new Student("Carson","Sean","2014",new Study("IG"),1991));
		 listStudents.put("Maite",new Student("Ross","Maite","2014",new Study("IG"),1988));
		 listStudents.put("Jasmine", new Student( "Roanna","Jasmine","2014",new Study("IG"),1992));
		 listStudents.put("Uma", new Student("Gabriel","Uma","2014",new Study("IG"),1993));
		 listStudents.put("Blake", new Student("Camille","Blake","2014",new Study("IG"),1994));
		 listStudents.put("Dahlia", new Student("Thor","Dahlia","2013",new Study("IG"),1995));
		 listStudents.put("Shafira",new Student("Sebastian","Shafira","2013",new Study("IG"),1992));
		 listStudents.put("Kellie",new Student("Imelda","Kellie","2013",new Study("IG"),1994));
		 listStudents.put("Kieran",new Student("Priscilla","Kieran","2013",new Study("IG"),1998));
		 listStudents.put("Griffin",new Student("Yvonne","Griffin","2013",new Study("IG"),1987));
		 listStudents.put("Sade",new Student("Hiram","Sade","2012",new Study("ID"),1994));
		 listStudents.put("Risa",new Student("James","Risa","2012",new Study("ID"),1994));
		 listStudents.put("Kasimir",new Student("Teagan","Kasimir","2012",new Study("ID"),1994));
		 listStudents.put("Iliana",new Student("Aquila","Iliana","2012",new Study("ID"),1994));
		 listStudents.put("Samson",new Student("Jada","Samson","2012",new Study("ID"),1994));
		 listStudents.put("Stephen",new Student("Sandra","Stephen","2012",new Study("ID"),1994));
		 listStudents.put("Silas",new Student("Ferris","Silas","2015",new Study("ID"),1994));
		 listStudents.put("Mason",new Student("Beck","Mason","2015",new Study("ID"),1994));
		 listStudents.put("Zachery",new Student("Melvin","Zachery","2015",new Study("ID"),1994));
		 listStudents.put("Ariel",new Student("Ignacia","Ariel","2015",new Study("ID"),1994));
		 listStudents.put("Malcolm",new Student("Irma","Malcolm","2015",new Study("ID"),1994));
		 listStudents.put("Zahir",new Student("Wade","Zahir","2015",new Study("EE"),1994));
		 listStudents.put("Orla",new Student("Wesley","Orla","2015",new Study("EE"),1994));
		 listStudents.put("Mannix",new Student("Irene","Mannix","2015",new Study("EE"),1994));
		 listStudents.put("Anastasia",new Student("Alfreda","Anastasia","2015",new Study("EE"),1994));
		 listStudents.put("Christen",new Student("Barclay","Christen","2015",new Study("EE"),1994));
		 listStudents.put("Marshall",new Student("Rajah","Marshall","2013",new Study("EE"),1994));
		 listStudents.put("Stuart",new Student("Ulric","Stuart","2013",new Study("EE"),1994));
		 listStudents.put("Forrest",new Student("Darryl","Forrest","2013",new Study("EE"),1994));
		 listStudents.put("Moses",new Student("Meredith","Moses","2013",new Study("EE"),1994));
		 listStudents.put("Oscar",new Student("Simon","Oscar","2013",new Study("EE"),1994));
		 listStudents.put("Brandon",new Student("Libby","Brandon","2013",new Study("EE"),1991));
		 listStudents.put("Ina",new Student("Inez","Ina","2013",new Study("IBM"),1990));
		 listStudents.put("Ruth",new Student("Macon","Ruth","2013",new Study("IBM"),1992));
		 listStudents.put("Barclay",new Student("Moses","Barclay","2013",new Study("IBM"),1991));
		 listStudents.put("Tasha",new Student("Teagan","Tasha","2013",new Study("IBM"),1994));
		 listStudents.put("Zachary",new Student("Aladdin","Zachary","2013",new Study("IBM"),1994));
		 listStudents.put("Hilel",new Student("Cadman","Hilel","2013",new Study("IBM"),1993));
		 listStudents.put("Isabelle",new Student("Kato","Isabelle","2013",new Study("IBM"),1991));
		 listStudents.put("Cooper",new Student("Christen","Cooper","2013",new Study("IBM"),1995));
		 listStudents.put("Adele",new Student("Brock","Adele","2013",new Study("IBM"),1990));
		 listStudents.put("Winter",new Student("Zachary","Winter","2013",new Study("IBM"),1994));
		 listStudents.put("Wynter",new Student("Minerva","Wynter","2013",new Study("IBM"),1991));
	
	} 
}
