package com.student.resources;

public abstract class Person {
		
	protected String nom;
	protected String prenom;
	protected int anneeNaissance;
	protected String id; 
	
	
	public Person(String nom, String prenom,int anneeNaissance) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.anneeNaissance=anneeNaissance;
		id=nom.substring(0, 2)+prenom.substring(0,2)+anneeNaissance;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAnneeNaissance() {
		return anneeNaissance;
	}

	public void setAnneeNaissance(int anneeNaissance) {
		this.anneeNaissance = anneeNaissance;
	}

	public String getId() {
		return id;
	}
	
}

