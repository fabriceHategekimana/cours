package com.student.resources;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student extends Person{
	
	public Student() {}
	
	private String anneeInscription;
	private Study filiere;

	public Student(String nom, String prenom, String anneeInscription, Study filiere, int anneeNaissance) {
		super(nom, prenom,anneeNaissance);
		this.anneeInscription = anneeInscription;
		this.filiere = filiere;
	}

	public String getAnneeInscription() {
		return anneeInscription;
	}

	public void setAnneeInscription(String anneeInscription) {
		this.anneeInscription = anneeInscription;
	}

	public Study getFiliere() {
		return filiere;
	}

	public void setFiliere(Study filiere) {
		this.filiere = filiere;
	}

	@Override
	public String toString() {
		return "Etudiant [anneeInscription=" + anneeInscription + ", filiere=" + filiere + ", nom=" + nom + ", prenom="
				+ prenom + ", anneeNaissance=" + anneeNaissance + ", id=" + id + "]\n";
	}
	
	
}
