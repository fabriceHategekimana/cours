public interface AbstractFactory{
	FilDActualite getFilDActualite();
}
