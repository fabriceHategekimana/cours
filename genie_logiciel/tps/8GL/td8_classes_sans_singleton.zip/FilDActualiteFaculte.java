public class FilDActualiteFaculte implements AbstractFactory{

	public FilDActualite getFilDActualite(){ 
		return new Faculte();
	}
}

