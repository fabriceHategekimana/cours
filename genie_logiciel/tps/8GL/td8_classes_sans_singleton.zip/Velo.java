public class Livre extends Objets{
	String Autheur;
	public Livre(String Nom, String Proprietaire, int Prix, String Description, String Labels, String Autheur){
		super(String Nom, String Proprietaire, int Prix, String Description, String Labels);
		this.Autheur= Autheur;
	}	
}
