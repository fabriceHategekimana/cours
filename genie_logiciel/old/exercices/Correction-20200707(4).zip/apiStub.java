package com.tp7.data.api;

import java.util.Arrays;
import java.util.List;

public class APIStub implements API {

	public List<String> retrieveCities(String country) {
		return Arrays.asList("cleveland","boston", "new York", "baltimore", "cincinnati");
	}
}
