package com.tp7.test;

import static org.junit.Assert.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.tp7.business.BusinessImpl;
import com.tp7.data.api.API;

public class BusinessImplMock {

	@Test
	public void testRetrieveCitiesStartingWithC_mock() {
		
		API apiMock = mock(API.class);
		
		List<String> cities = Arrays.asList("cleveland","boston", "new York", "baltimore", "cincinnati");
		
		when(apiMock.retrieveCities("United States")).thenReturn(cities);
		
		
		BusinessImpl BusinessImpl = new BusinessImpl(apiMock);
		
		List<String> citiesOfInterest = BusinessImpl.retrieveCitiesStartingWithC("United States");
		for(String cityC : citiesOfInterest) {
            System.out.println(cityC);
        }
		assertEquals(2, citiesOfInterest.size());
	}
	
	
	@Test
	public void testgetNumberOfCities_mock() {
		
		API apiMock = mock(API.class);
		
		List<String> cities = Arrays.asList("cleveland","boston", "new York", "baltimore", "cincinnati");
		
		when(apiMock.retrieveCities(anyString())).thenReturn(cities);
		
		
		BusinessImpl BusinessImpl = new BusinessImpl(apiMock);
		
		Integer numberOfCities = BusinessImpl.getNumberOfCities("Switzerland");
        System.out.println(numberOfCities);
		assertEquals(5, numberOfCities,0);
	}
}




