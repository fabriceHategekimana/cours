package com.tp7.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.tp7.business.BusinessImpl;
import com.tp7.data.api.API;
import com.tp7.data.api.APIStub;

public class BusinessImplStub {

	@Test
	public void testRetrieveCitiesStartingWithC_stub() {
		API apiStub = new APIStub();
		BusinessImpl businessImpl = 
				new BusinessImpl(apiStub);
		List<String> citiesOfInterest = businessImpl
				.retrieveCitiesStartingWithC("United States");
		for(String cityC : citiesOfInterest) {
            System.out.println(cityC);
        }
		assertEquals(2, citiesOfInterest.size());
	}
	
	@Test
	public void testRetrieveCitiesStartngWithC_stub() {
		API apiStub = new APIStub();
		BusinessImpl businessImpl = 
				new BusinessImpl(apiStub);
		List<String> citiesOfInterest = businessImpl
				.retrieveCitiesStartingWithC("United States");
		for(String cityC : citiesOfInterest) {
            System.out.println(cityC);
        }
		assertEquals(2, 0);
	}

}
