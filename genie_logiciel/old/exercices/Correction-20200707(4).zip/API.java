package com.tp7.data.api;

import java.util.List;

public interface API {
	public List<String> retrieveCities(String country);

}