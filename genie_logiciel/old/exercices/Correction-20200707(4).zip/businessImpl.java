package com.tp7.business;

import java.util.ArrayList;
import java.util.List;
import com.tp7.data.api.API;

public class BusinessImpl {
	
	private API api;

	public BusinessImpl(API api) {
		this.api = api;
	}
	
	public List<String> retrieveCitiesStartingWithC(String country){
		List<String> citiesOfInterest = new ArrayList<String>();
		List<String> cities = api.retrieveCities(country);
		for(String city:cities) {
			if(city.startsWith("c")) {
				citiesOfInterest.add(city);
			}
		}
		return citiesOfInterest;
		
	}
	
	public Integer getNumberOfCities(String country){
		List<String> cities = api.retrieveCities(country);
		return cities.size();
		
	}
}
