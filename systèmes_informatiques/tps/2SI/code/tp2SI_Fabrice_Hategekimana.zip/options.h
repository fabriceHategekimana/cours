int option(int argc, char *argv[], int *index, char *fonctionDeHashage);
