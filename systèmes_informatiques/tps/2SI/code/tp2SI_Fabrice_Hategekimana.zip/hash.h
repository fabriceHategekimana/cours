int hashage(char *mess, char *digestName);
void hasher(char *nom, char *digestName);
