void getRWX(unsigned short droit);
int droits(unsigned short mode);
int displayStat(char *element);
void RecursiveDisplay(char *entry);
