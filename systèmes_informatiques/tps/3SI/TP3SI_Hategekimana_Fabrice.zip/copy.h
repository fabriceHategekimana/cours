
int createDir(char *folder);
int copy(const char *from, const char *to);
void RecursiveCopy(char *entry, char *folder);
int remplacer(char *source_file, char *target_file);
