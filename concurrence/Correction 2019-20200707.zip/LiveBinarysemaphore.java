package tp3quest3ElhamAmin;

import java.util.Queue;

public class Binarysemaphore {

	private Object o1 = new Object();
	private Object o2 = new Object();
	
	private int cp1 = 0;
	private int cp2 = 0;
	
	
	public Binarysemaphore() {
		
	
	}
	public void P()  { 
		
		synchronized(o1) {
			cp1++;
			if(cp1 > 1) {
					try {
						o1.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		synchronized(o2) {
				cp2++;
				if(cp2 > 1) {
						try {
							o2.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				
		}
		
	}
	public void V() { // protocole de sortie de SC
		synchronized(o2) {
			cp2--;
			if(cp2 >= 1) {
				o2.notifyAll();	
			}
		}
		synchronized(o1) {
			if(cp2 == 0) {
				cp1 = 0;
				o1.notifyAll();
			}
		}
			
			
	}
}
	
