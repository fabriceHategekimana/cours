public class LiveSemaphore{
	
	private volatile int num;
	private Object o;
	
	public LiveSemaphore() {
		num = 0;
		o = new Object();
	}

	
	public void P() {
		synchronized(o) {
			if (num > 0)  
				try {o.wait();} catch (InterruptedException e) {}
		}
		synchronized(this) {
			num++; 
			if (num > 1) 
				try {this.wait();} catch (InterruptedException e) {}
		}
	}

	
	public synchronized void V() {
		synchronized(fifo) {
			num--;
			if (num == 0) o.notifyAll();
			else this.notify();
		}
	}
}
