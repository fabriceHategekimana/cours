import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Arrays;

public class Pont{
	
	private List<Message> portIn; 
	private List<Message> portOut; 
	private int idPont;
	private int vectorDistance[];
	private int nextHop[];  

	public Pont(int id, List<Message> pIn, List<Message> pOut, int initialDistance[], int neighbors[]){
		idPont=id;
		portIn=pIn;
		portOut=pOut;
		vectorDistance=initialDistance.clone();
		sendMessage();
		nextHop=neighbors.clone();
	}

	public void checkMessage(){  
		Iterator it=portIn.iterator();
		while(it.hasNext()){
			Message inter = (Message)it.next();
			   // a compl�ter
				}
			}
		}
	}

	public void sendMessage(){

		for(int i=0; i< portOut.size(); i++){
			Message m=portOut.get(i);
			m.update(vectorDistance);
		}
	}
	
	public void printRoutingTable(){
		
		System.out.println("Pont "+ idPont + ":" );
		System.out.println("Vector distance:" + Arrays.toString(vectorDistance) + "");
		System.out.println("Next Hop: " + Arrays.toString(nextHop) + "\n\n");
	}
	
}

