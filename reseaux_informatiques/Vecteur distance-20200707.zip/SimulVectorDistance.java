import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class SimulVectorDistance{

	public static void main(String args[]) throws IOException{

		Message m12=new Message(1,new int[4]);
		Message m13=new Message(1,new int[4]);
		Message m23=new Message(2,new int[4]);
		Message m24=new Message(2,new int[4]);
		Message m34=new Message(3,new int[4]);
		
		Message m21=new Message(2,new int[4]);
		Message m31=new Message(3,new int[4]);
		Message m32=new Message(3,new int[4]);
		Message m42=new Message(4,new int[4]);
		Message m43=new Message(4,new int[4]);

		List<Message> l1in=new ArrayList<Message>();
		l1in.add(m21);
		l1in.add(m31);
		
		List<Message> l1out=new ArrayList<Message>();
		l1out.add(m12);
		l1out.add(m13);

		
		List<Message> l2in=new ArrayList<Message>();
		l2in.add(m12);
		l2in.add(m32);
		l2in.add(m42);
		
		List<Message> l2out=new ArrayList<Message>();
		l2out.add(m21);
		l2out.add(m23);
		l2out.add(m24);
	
		List<Message> l3in=new ArrayList<Message>();
		l3in.add(m13);
		l3in.add(m23);
		l3in.add(m43);
		
		
		List<Message> l3out=new ArrayList<Message>();
		l3out.add(m31);
		l3out.add(m32);
		l3out.add(m34);

		List<Message> l4in=new ArrayList<Message>();
		l4in.add(m24);
		l4in.add(m34);		
		List<Message> l4out=new ArrayList<Message>();
		l4out.add(m42);
		l4out.add(m43);

		Pont p1=new Pont(1,l1in, l1out,new int[]{0,1,1,1000},new int[] {0,2,3,0});
		Pont p2=new Pont(2,l2in,l2out,new int[]{1,0,1,1},new int[] {1,0,3,4});
		Pont p3=new Pont(3,l3in, l3out,new int[]{1,1,0,1},new int[] {1,2,0,4});
		Pont p4=new Pont(4,l4in,l4out,new int[]{1000,1,1,0},new int[] {0,2,3,0});


		while(true){
			p1.printRoutingTable();
			System.out.println("===========================");
			p2.printRoutingTable();
			System.out.println("===========================");
			p3.printRoutingTable();
			System.out.println("===========================");
			p4.printRoutingTable();

			while(System.in.read()!='\n'){}

			System.out.println("p1 transmet");

			p1.sendMessage();
			p2.checkMessage();
			p3.checkMessage();
			p4.checkMessage();

			p1.printRoutingTable();
			System.out.println("===========================");
			p2.printRoutingTable();
			System.out.println("===========================");
			p3.printRoutingTable();
			System.out.println("===========================");
			p4.printRoutingTable();
			
			while(System.in.read()!='\n'){}


			System.out.println("p2 transmet");
			
			p2.sendMessage();
			p1.checkMessage();
			p3.checkMessage();
			p4.checkMessage();

			p1.printRoutingTable();
			System.out.println("===========================");
			p2.printRoutingTable();
			System.out.println("===========================");
			p3.printRoutingTable();
			System.out.println("===========================");
			p4.printRoutingTable();

			while(System.in.read()!='\n'){}
			
			
			System.out.println("p3 transmet");

			p3.sendMessage();
			p1.checkMessage();
			p2.checkMessage();
			p4.checkMessage();

			p1.printRoutingTable();
			System.out.println("===========================");
			p2.printRoutingTable();
			System.out.println("===========================");
			p3.printRoutingTable();
			System.out.println("===========================");
			p4.printRoutingTable();

			while(System.in.read()!='\n'){}
			

			System.out.println("p4 transmet");
			
			p4.sendMessage();
			p1.checkMessage();
			p2.checkMessage();
			p3.checkMessage();
			
			p1.printRoutingTable();
			System.out.println("===========================");
			p2.printRoutingTable();
			System.out.println("===========================");
			p3.printRoutingTable();
			System.out.println("===========================");
			p4.printRoutingTable();
	    }
	}
}
