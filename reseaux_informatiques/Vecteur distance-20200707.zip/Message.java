public class Message {
	
	public int[] message;
	public int idSender;

	public Message(int id, int[] m){
		message = m;
		idSender = id;
	}
	
	public void update(int [] m){
		message = m;
	}
}
