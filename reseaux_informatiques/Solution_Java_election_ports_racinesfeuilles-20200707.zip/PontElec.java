import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class PontElec{

	public PontElec(int id, List<MessageElec> pIn, List<MessageElec> pOut){
		idPont=id;
		portIn=pIn;
		portOut=pOut;

		localMin=new MessageElec(id, 0, id);

	}

	public void checkMessage(){  // selectionne le plus petit des messages recu et de l'etat courant

		Iterator it=portIn.iterator();
		while(it.hasNext()){
			MessageElec inter = (MessageElec)it.next();
			inter.feuille=false;
			inter.racine=false;
			if(localMin.compareTo(inter)){   // test si localMin < inter
				localMin.assign(inter);
			}
		}
		MessageElec envoi=new MessageElec();
		envoi.assignpp(localMin, idPont);
		if (idPont == localMin.idRacine)
			envoi.distance--;          // inter le message envoye par le pont

		if (localMin.idRacine != idPont) {   // election port racine
			it=portIn.iterator();
			while(it.hasNext()){
				MessageElec inter = (MessageElec)it.next();
				if(localMin.eq(inter)){   // test si localMin < inter
					inter.racine=true;
				}
			}
		}
		it=portIn.iterator();    // election port feuille
		while(it.hasNext()){
			MessageElec inter = (MessageElec)it.next();
			if(inter.compareTo(envoi)){   // test si localMin < inter
				inter.feuille=true;
			}
		}
	}

	public void sendMessage(){

		MessageElec inter=new MessageElec();
		inter.assignpp(localMin, idPont);
		if (idPont == localMin.idRacine)
			inter.distance--;
		for(int i=0; i< portOut.size(); i++){
			MessageElec m=portOut.get(i);
			m.assign(inter);
		}
	}
			



	public void printMessage(){
		System.out.println("Pont id "+idPont);
		System.out.println("port in");
		Iterator it = portIn.iterator();
		while (it.hasNext()){
			MessageElec inter = (MessageElec)it.next();
			System.out.println("("+inter.idRacine+", "+inter.distance+", "+inter.idSender+")   "+inter.racine+"   "+inter.feuille);
		}

		System.out.println("port out");		
		it = portOut.iterator();
		while (it.hasNext()){
			MessageElec inter = (MessageElec)it.next();
			System.out.println("("+inter.idRacine+", "+inter.distance+", "+inter.idSender+")   "+inter.racine+"   "+inter.feuille);
		}
		System.out.println("localMin ");
		System.out.println("("+localMin.idRacine+", "+localMin.distance+", "+localMin.idSender+")"+")    "+localMin.racine+"   "+localMin.feuille);
		
	}

	private List<MessageElec> portIn;   // dernier messages recus - le numero du port est l'index dans la liste
	private List<MessageElec> portOut;  // dernier messages transmis - le numero du port est l'index dans la liste

	private int idPont;          // l'identificateur du pont
	private MessageElec localMin;
	
}

