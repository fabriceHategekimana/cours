public class MessageElec {

	public MessageElec(){
		idRacine=0;
		distance=0;
		idSender=0;
		racine=false;
		feuille=false;
	}

	public MessageElec(int id, int dist, int idS){
		idRacine=id;
		distance=dist;
		idSender=idS;
		racine=false;
		feuille=false;
	}


	public boolean compareTo(int id, int dist, int idS){ // return true si this > false sinon 
		if(id<idRacine)
			return true;
		else if ((id==idRacine) && (dist<distance))
			return true;
		else if ((id==idRacine) && (dist==distance) && (idS < idSender))
			return true;

		return false;
	}

	public boolean compareTo(MessageElec m){ // return true si m<this false sinon 
		if(m.idRacine<idRacine)
			return true;
		else if ((m.idRacine==idRacine) && (m.distance<distance))
			return true;
		else if ((m.idRacine==idRacine) && (m.distance==distance) && (m.idSender < idSender))
			return true;

		return false;
	}

	public boolean eq(MessageElec m){  // return true if eq
		return ((m.idRacine==idRacine)&&(m.distance==distance)&&(m.idSender==idSender));
	}

	public void assign(MessageElec m){
		idRacine=m.idRacine;
		distance=m.distance;
		idSender=m.idSender;
		feuille=false;
		racine=false;
	}

	public void assignpp(MessageElec m, int idPont){
		idRacine=m.idRacine;
		distance=m.distance+1;
		idSender=idPont;
		feuille=false;
		racine=false;
	}



	int idRacine;
	int distance;
	int idSender;
	boolean racine;
	boolean feuille;
}


