import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
//import interfaceHello.HelloInterface;

import java.rmi.server.UnicastRemoteObject;

public class HelloServeur implements HelloInterface {

	public HelloServeur(String s){
		super();
		message=s;
	}

	private String message;
	private int count;

	public String sayHello() throws RemoteException{
		return message+count++;
	}

	public static void main(String [] argv) {
		/* lancer SecurityManager */
		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new SecurityManager());
		}
		try {
			HelloInterface testObj = new HelloServeur("Hello world");
			HelloInterface stub = (HelloInterface) UnicastRemoteObject.exportObject(testObj,0);

			Registry registry = LocateRegistry.getRegistry();
			registry.rebind("Hello" , stub);
			System.out.println("Serveur pret . ");
		} catch ( Exception e ) { 
			System.out.println("Erreur serveur : " + e ) ;		
		}		
	}
}

