import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class Simul8021dThread{

	public static void main(String args[]) throws IOException{

		MessageThread m12=new MessageThread(100,100,100);
		MessageThread m13=new MessageThread(100,100,100);
		MessageThread m23=new MessageThread(100,100,100);
		MessageThread m24=new MessageThread(100,100,100);
		MessageThread m34=new MessageThread(100,100,100);

		MessageThread m21=new MessageThread(100,100,100);
		MessageThread m31=new MessageThread(100,100,100);
		MessageThread m32=new MessageThread(100,100,100);
		MessageThread m42=new MessageThread(100,100,100);
		MessageThread m43=new MessageThread(100,100,100);

		List<MessageThread> l1in=new ArrayList<MessageThread>();
		l1in.add(m21);
		l1in.add(m31);
		
		List<MessageThread> l1out=new ArrayList<MessageThread>();
		l1out.add(m12);
		l1out.add(m13);

		
		List<MessageThread> l2in=new ArrayList<MessageThread>();
		l2in.add(m12);
		l2in.add(m32);
		l2in.add(m42);
		
		List<MessageThread> l2out=new ArrayList<MessageThread>();
		l2out.add(m21);
		l2out.add(m23);
		l2out.add(m24);
	
		List<MessageThread> l3in=new ArrayList<MessageThread>();
		l3in.add(m13);
		l3in.add(m23);
		l3in.add(m43);
		
		
		List<MessageThread> l3out=new ArrayList<MessageThread>();
		l3out.add(m31);
		l3out.add(m32);
		l3out.add(m34);

		List<MessageThread> l4in=new ArrayList<MessageThread>();
		l4in.add(m24);
		l4in.add(m34);		
		List<MessageThread> l4out=new ArrayList<MessageThread>();
		l4out.add(m42);
		l4out.add(m43);


		PontThread p1=new PontThread(1,l1in, l1out);
		PontThread p2=new PontThread(2,l2in,l2out);
		PontThread p3=new PontThread(3,l3in, l3out);
		PontThread p4=new PontThread(4,l4in,l4out);


		p1.start();
		p2.start();
		p3.start();
		p4.start();
	}
}
