import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class PontThread extends Thread{

	public PontThread(int id, List<MessageThread> pIn, List<MessageThread> pOut){
		idPont=id;
		portIn=pIn;
		portOut=pOut;

		localMin=new MessageThread(id, 0, id);

	}

	public void checkMessage(){  // selectionne le plus petit des messages recu et de l'etat courant

		Iterator it=portIn.iterator();
		while(it.hasNext()){
			MessageThread inter = (MessageThread)it.next();
			if(localMin.compareTo(inter)){   // test si localMin < inter
				localMin.assign(inter);
				System.out.println("Pont "+idPont+"("+inter.idRacine+", "+inter.distance+", "+inter.idSender+")");
			}
		}
	}

	public void sendMessage(){

		MessageThread inter=new MessageThread();
		inter.assignpp(localMin, idPont);
		if (idPont == localMin.idRacine)
			inter.distance--;
		for(int i=0; i< portOut.size(); i++){
			MessageThread m=portOut.get(i);
			m.assign(inter);
		}
	}

	public void run(){
		while(true){
			checkMessage();
			sendMessage();
		}
	}
			



	private List<MessageThread> portIn;   // dernier messages recus - le numero du port est l'index dans la liste
	private List<MessageThread> portOut;  // dernier messages transmis - le numero du port est l'index dans la liste

	private int idPont;          // l'identificateur du pont
	private MessageThread localMin;
	
}

