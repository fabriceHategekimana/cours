import java.io.*;

import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

public class Pont{

	public Pont(int id, List<Message> pIn, List<Message> pOut){
		idPont=id;
		portIn=pIn;
		portOut=pOut;

		localMin=new Message(id, 0, id);

	}

	public void checkMessage(){  // selectionne le plus petit des messages recu et de l'etat courant

		Iterator it=portIn.iterator();
		while(it.hasNext()){
			Message inter = (Message)it.next();
			if(localMin.compareTo(inter)){   // test si localMin < inter
				localMin.assign(inter);
			}
		}
	}

	public void sendMessage(){

		Message inter=new Message();
		inter.assignpp(localMin, idPont);
		if (idPont == localMin.idRacine)
			inter.distance--;
		for(int i=0; i< portOut.size(); i++){
			Message m=portOut.get(i);
			m.assign(inter);
		}
	}
			



	public void printMessage(){
		System.out.println("Pont id "+idPont);
		System.out.println("port in");
		Iterator it = portIn.iterator();
		while (it.hasNext()){
			Message inter = (Message)it.next();
			System.out.println("("+inter.idRacine+", "+inter.distance+", "+inter.idSender+")");
		}

		System.out.println("port out");		
		it = portOut.iterator();
		while (it.hasNext()){
			Message inter = (Message)it.next();
			System.out.println("("+inter.idRacine+", "+inter.distance+", "+inter.idSender+")");
		}
		System.out.print("localMin ");
		System.out.println("("+localMin.idRacine+", "+localMin.distance+", "+localMin.idSender+")");
		
	}

	private List<Message> portIn;   // dernier messages recus - le numero du port est l'index dans la liste
	private List<Message> portOut;  // dernier messages transmis - le numero du port est l'index dans la liste

	private int idPont;          // l'identificateur du pont
	private Message localMin;
	
}

