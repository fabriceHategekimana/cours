public class Message {

	public Message(){
		idRacine=0;
		distance=0;
		idSender=0;
	}

	public Message(int id, int dist, int idS){
		idRacine=id;
		distance=dist;
		idSender=idS;
	}


	public boolean compareTo(int id, int dist, int idS){ // return true si this > false sinon 
		if(id<idRacine)
			return true;
		else if ((id==idRacine) && (dist<distance))
			return true;
		else if ((id==idRacine) && (dist==distance) && (idS < idSender))
			return true;

		return false;
	}

	public boolean compareTo(Message m){ // return true si m<this false sinon 
		if(m.idRacine<idRacine)
			return true;
		else if ((m.idRacine==idRacine) && (m.distance<distance))
			return true;
		else if ((m.idRacine==idRacine) && (m.distance==distance) && (m.idSender < idSender))
			return true;

		return false;
	}

	public void assign(Message m){
		idRacine=m.idRacine;
		distance=m.distance;
		idSender=m.idSender;
	}

	public void assignpp(Message m, int idPont){
		idRacine=m.idRacine;
		distance=m.distance+1;
		idSender=idPont;
	}



	int idRacine;
	int distance;
	int idSender;
}


